﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace WpfApp1
{
    public partial class UserControl1 : UserControl
    {
        private Queue<(DirectoryInfo, TreeViewItem)> directoryQueue = new Queue<(DirectoryInfo, TreeViewItem)>();
        private int itemCount = 0;
        private List<FileItem> fileItems = new List<FileItem>();
        private string currentSortColumn = string.Empty;
        private bool sortAscending = true;

        public UserControl1()
        {
            InitializeComponent();
            ReadDDrive();
        }

        private void ReadDDrive()
        {
            try
            {
                ItemCountTextBlock.Text = "Items: 0";
                DirectoryInfo rootDirectory = new DirectoryInfo("D:\\");
                TreeViewItem rootItem = new TreeViewItem() { Header = rootDirectory.FullName, Tag = rootDirectory };
                RootNode.Items.Add(rootItem);
                directoryQueue.Enqueue((rootDirectory, rootItem));

                while (directoryQueue.Count > 0)
                {
                    var (currentDirectory, parentItem) = directoryQueue.Dequeue();

                    Console.WriteLine($"Directory: {currentDirectory.FullName}");

                    try
                    {
                        DirectoryInfo[] subDirectories = currentDirectory.GetDirectories();
                        foreach (var subDir in subDirectories)
                        {
                            if (subDir.Attributes.HasFlag(FileAttributes.Hidden)) continue;

                            TreeViewItem subItem = new TreeViewItem() { Header = subDir.Name, Tag = subDir };
                            parentItem.Items.Add(subItem);
                            directoryQueue.Enqueue((subDir, subItem));
                            itemCount++;
                        }

                        FileInfo[] files = currentDirectory.GetFiles();
                        foreach (var file in files)
                        {
                            if (file.Attributes.HasFlag(FileAttributes.Hidden)) continue;

                            Console.WriteLine($"File: {file.FullName}");
                            TreeViewItem fileItem = new TreeViewItem() { Header = file.Name, Tag = file };
                            parentItem.Items.Add(fileItem);
                            itemCount++;
                        }
                        ItemCountTextBlock.Text = rootDirectory + $" 有{itemCount}個項目";

                    }
                    catch (UnauthorizedAccessException ex)
                    {
                        Console.WriteLine($"Access denied: {ex.Message}");
                    }
                    catch (DirectoryNotFoundException ex)
                    {
                        Console.WriteLine($"Directory not found: {ex.Message}");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error reading drive: {ex.Message}");
            }
        }

        private void CreateFolder_Click(object sender, RoutedEventArgs e)
        {
            if (DirectoryTree.SelectedItem is TreeViewItem selectedItem)
            {
                DirectoryInfo directoryInfo = selectedItem.Tag as DirectoryInfo;
                if (directoryInfo != null)
                {
                    FolderNameDialog dialog = new FolderNameDialog();
                    if (dialog.ShowDialog() == true)
                    {
                        string newFolderPath = Path.Combine(directoryInfo.FullName, dialog.FolderName);
                        Directory.CreateDirectory(newFolderPath);
                        TreeViewItem newFolderItem = new TreeViewItem() { Header = dialog.FolderName, Tag = new DirectoryInfo(newFolderPath) };
                        selectedItem.Items.Add(newFolderItem);
                        selectedItem.IsExpanded = true;
                    }
                }
            }
        }

        private void RenameFolder_Click(object sender, RoutedEventArgs e)
        {
            if (DirectoryTree.SelectedItem is TreeViewItem selectedItem)
            {
                DirectoryInfo directoryInfo = selectedItem.Tag as DirectoryInfo;
                if (directoryInfo != null)
                {
                    FolderNameDialog dialog = new FolderNameDialog();
                    dialog.FolderNameTextBox.Text = directoryInfo.Name;
                    if (dialog.ShowDialog() == true)
                    {
                        string newFolderName = dialog.FolderName;
                        string newFolderPath = Path.Combine(directoryInfo.Parent.FullName, newFolderName);
                        Directory.Move(directoryInfo.FullName, newFolderPath);
                        selectedItem.Header = newFolderName;
                        selectedItem.Tag = new DirectoryInfo(newFolderPath);
                    }
                }
            }
        }

        private void DeleteFolder_Click(object sender, RoutedEventArgs e)
        {
            if (DirectoryTree.SelectedItem is TreeViewItem selectedItem)
            {
                DirectoryInfo directoryInfo = selectedItem.Tag as DirectoryInfo;
                if (directoryInfo != null)
                {
                    Directory.Delete(directoryInfo.FullName, true);
                    TreeViewItem parentItem = selectedItem.Parent as TreeViewItem;
                    if (parentItem != null)
                    {
                        parentItem.Items.Remove(selectedItem);
                    }
                    else
                    {
                        RootNode.Items.Remove(selectedItem);
                    }
                }
            }
        }

        private void DirectoryTree_MouseRightButtonDown(object sender, MouseButtonEventArgs e)
        {
            TreeView treeView = sender as TreeView;
            if (treeView != null)
            {
                if (treeView.SelectedItem != null)
                {
                    ContextMenu contextMenu = (ContextMenu)this.Resources["DirectoryContextMenu"];
                    contextMenu.PlacementTarget = treeView;
                    contextMenu.IsOpen = true;
                }
            }
        }

        private void DirectoryTree_SelectedItemChanged(object sender, RoutedPropertyChangedEventArgs<object> e)
        {
            if (DirectoryTree.SelectedItem is TreeViewItem selectedItem)
            {
                DirectoryInfo directoryInfo = selectedItem.Tag as DirectoryInfo;
                if (directoryInfo != null)
                {
                    DisplayDirectoryContents(directoryInfo);
                    ItemCountTextBlock.Text = directoryInfo.FullName + $" 有{itemCount}個項目";
                    PathTextBox.Text = directoryInfo.FullName;
                }
            }
        }

        private void DisplayDirectoryContents(DirectoryInfo directoryInfo)
        {
            fileItems.Clear();
            itemCount = 0;
            try
            {
                foreach (var subDir in directoryInfo.GetDirectories())
                {
                    if (!subDir.Attributes.HasFlag(FileAttributes.Hidden))
                    {
                        fileItems.Add(new FileItem { Name = subDir.Name, Extension = "Folder", Size = 0, LastModified = subDir.LastWriteTime, IsDirectory = true });
                        itemCount++;
                    }
                }

                foreach (var file in directoryInfo.GetFiles())
                {
                    if (!file.Attributes.HasFlag(FileAttributes.Hidden))
                    {
                        fileItems.Add(new FileItem { Name = file.Name, Extension = file.Extension, Size = file.Length, LastModified = file.LastWriteTime, IsDirectory = false });
                        itemCount++;
                    }
                }

                FileList.ItemsSource = null;
                FileList.ItemsSource = fileItems;
            }
            catch (UnauthorizedAccessException ex)
            {
                Console.WriteLine($"Access denied: {ex.Message}");
            }
            catch (DirectoryNotFoundException ex)
            {
                Console.WriteLine($"Directory not found: {ex.Message}");
            }
        }

        private void PathTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            string path = PathTextBox.Text;
            if (Directory.Exists(path))
            {
                DirectoryInfo directoryInfo = new DirectoryInfo(path);
                DisplayDirectoryContents(directoryInfo);
                ItemCountTextBlock.Text = path + $" 搜尋後有{itemCount}個項目";
            }
        }

        private void SearchButton_Click(object sender, RoutedEventArgs e)
        {
            string path = PathTextBox.Text;
            if (Directory.Exists(path))
            {
                DirectoryInfo directoryInfo = new DirectoryInfo(path);
                DisplayDirectoryContents(directoryInfo);
                ItemCountTextBlock.Text = path + $" 搜尋後有{itemCount}個項目";
            }
            else
            {
                MessageBox.Show("無搜尋到相關路徑.");
            }
        }

        private void FileList_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            if (FileList.SelectedItem != null)
            {
                dynamic selectedItem = FileList.SelectedItem;
                string filePath = Path.Combine(GetCurrentDirectoryPath(), selectedItem.Name);

                try
                {
                    Process.Start(new ProcessStartInfo(filePath) { UseShellExecute = true });
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Unable to open file: {ex.Message}");
                }
            }
        }

        private string GetCurrentDirectoryPath()
        {
            if (DirectoryTree.SelectedItem is TreeViewItem selectedItem)
            {
                DirectoryInfo directoryInfo = selectedItem.Tag as DirectoryInfo;
                return directoryInfo.FullName;
            }
            return string.Empty;
        }

        private void GridViewColumnHeader_Click(object sender, RoutedEventArgs e)
        {
            if (sender is GridViewColumnHeader header)
            {
                string sortBy = header.Column.Header as string;

                if (currentSortColumn == sortBy)
                {
                    sortAscending = !sortAscending;
                }
                else
                {
                    currentSortColumn = sortBy;
                    sortAscending = true;
                }

                SortFileItems();
            }
        }

        private void SortFileItems()
        {
            switch (currentSortColumn)
            {
                case "Name":
                    if (sortAscending)
                        FileList.ItemsSource = fileItems.OrderBy(f => f.Name).ToList();
                    else
                        FileList.ItemsSource = fileItems.OrderByDescending(f => f.Name).ToList();
                    break;
                case "Type":
                    if (sortAscending)
                        FileList.ItemsSource = fileItems.OrderBy(f => f.Extension).ToList();
                    else
                        FileList.ItemsSource = fileItems.OrderByDescending(f => f.Extension).ToList();
                    break;
                case "Size":
                    if (sortAscending)
                        FileList.ItemsSource = fileItems.OrderBy(f => f.Size).ToList();
                    else
                        FileList.ItemsSource = fileItems.OrderByDescending(f => f.Size).ToList();
                    break;
                case "Last Modified":
                    if (sortAscending)
                        FileList.ItemsSource = fileItems.OrderBy(f => f.LastModified).ToList();
                    else
                        FileList.ItemsSource = fileItems.OrderByDescending(f => f.LastModified).ToList();
                    break;
            }
        }
    }

    public class FileItem
    {
        public string Name { get; set; }
        public string Extension { get; set; }
        public long Size { get; set; }
        public DateTime LastModified { get; set; }
        public bool IsDirectory { get; set; }
    }
}
